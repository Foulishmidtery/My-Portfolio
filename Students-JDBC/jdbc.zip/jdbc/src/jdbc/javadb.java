 
package jdbc;

/**
 *
 * @author jenki
 */
import java.sql.*; //1.import package
import javax.swing.JOptionPane;
public class javadb{
    void jdb() throws ClassNotFoundException, SQLException{
        String url = ("jdbc:mysql://localhost/siswa2");
        String user = "root";
        String password = "";
        String query = "select * from rpl";
        String insert = """
                        insert into rpl(ID,NAMA,UMUR,JENIS_KELAMIN) values(100,"adi", "16", "L")
                        """;
          String update = """
                          update rpl set NAMA = 'Yanto1' where ID = '13'
                          """;
          String delete = """
                          delete from rpl where ID = '18'
                        """;
        Class.forName("com.mysql.jdbc.Driver");//2.
        
        Connection con = DriverManager.getConnection(url, user, password);//3.
        
//        JOptionPane.showMessageDialog(null, "Koneksi Berhasil");

        Statement obj = con.createStatement();//4.
        obj.executeUpdate(insert);
        obj.executeUpdate(update);
        obj.executeUpdate(delete);
        
        
        ResultSet cih = obj.executeQuery(query);
        while(cih.next()){
            System.out.println(cih.getInt(1) + " : " + cih.getString(2) + " | "+ cih.getInt(3));
        }
    }
    public static void main(String[] args) throws Exception {
        javadb run = new javadb();
        run.jdb();
    }

}
