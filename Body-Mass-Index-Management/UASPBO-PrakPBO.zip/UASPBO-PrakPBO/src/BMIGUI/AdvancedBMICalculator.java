/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BMIGUI;

/**
 *
 * @author jenki
 */
public class AdvancedBMICalculator extends BMIService {
    @Override
    public double calculateBMI(double weight, double height) {
        System.out.println("Perhitungan Indeks Massa Tubuh");
        return super.calculateBMI(weight, height);
    }
}

