/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BMIGUI;

/**
 *
 * @author jenki
 */
public class BMIService implements Calculatable {
    private static final double CM_TO_M = 100.0;

    @Override
    public double calculateBMI(double weight, double height) {
        return weight / Math.pow(height / CM_TO_M, 2); 
    }

    public String getBMICategory(double bmi) {
        if (bmi < 18.5) return "Underweight";
        else if (bmi < 24.9) return "Normal weight";
        else if (bmi < 29.9) return "Overweight";
        else return "Obese";
    }
}

