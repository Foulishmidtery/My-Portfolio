/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pmr;

/**
 *
 * @author jenki
 */
import javax.swing.JOptionPane;
import java.sql.*;
public class koneksi {
    String koneksi;
    Connection con;
    void JDBC() throws ClassNotFoundException, SQLException{
        try{
            String url = "jdbc:mysql://localhost/pmr";
            String user = "root";
            String pass = "";
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url,user,pass);
            koneksi = "koneksi berhasil";
            
        }catch (Exception e){
            koneksi = "Koneksi gagal";
        }
    }
        
    public static void main(String[] args) throws Exception {
        koneksi jd = new koneksi();
        jd.JDBC();
    }
}

